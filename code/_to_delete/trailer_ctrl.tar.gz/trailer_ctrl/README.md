# trailer_ctrl -- controller for the TurtleBot3 with off-hooked trailers (no ROS)

Pure Python (numpy; scipy only for `sim.py` and the tests). It is the Python twin of the
MATLAB reference `1 trailer/trailer1.m` and `2 trailers/trailer2.m`. The ROS 2 node
(next step) only calls this package, so the controller can be tested without ROS, Gazebo or the robot.

## Files

| file | what |
|---|---|
| `geometry.py` | `Geometry`, coefficients alpha/kappa/theta/beta, state map `x -> z` (1 and 2 trailers) |
| `controller.py` | `Params`, `TrailerController` (amplitudes, `u(tau, z)`, worst-case bound, `gamma_max`), `SampledController` (fixed interval grid, freezing of `z`, saturation) |
| `sim.py` | offline closed loop on the approximation and on the exact kinematics (for tests/plots) |
| `configs/1tr.json`, `configs/2tr.json` | the design of thesis Chapters 6-7 (gamma, epsilon, k, Lyapunov function, limits) |
| `tests/test_vs_matlab.py` | compares everything with the reference numbers of the MATLAB selftest |

## Test

From the folder that contains `trailer_ctrl/`:

    python3 -m trailer_ctrl.tests.test_vs_matlab

It must end with `PORT TEST PASSED`. Reference numbers come from `selftest` in `trailer1.m` /
`trailer2.m` (18 Oct 2026, thesis design). If you change the design in `configs/*.json` on purpose,
the test fails on purpose: update the numbers from a fresh MATLAB selftest.

## Use (what the ROS node will do)

    import json
    from trailer_ctrl import Params, TrailerController, SampledController

    ctrl = TrailerController(Params.from_dict(json.load(open("configs/1tr.json"))))
    sc = SampledController(ctrl)
    sc.start(t_now)                       # t = 0 of the experiment
    ...
    cmd = sc.command(t_now, x_measured)   # x = [x1, x2, phi, theta1(, theta2)], UNWRAPPED angles
    publish(cmd.u1, cmd.u2)               # already saturated; cmd.clipped tells if that was active

## Rules that matter on the robot

* **Interval starts on a fixed grid** `t0 + j*epsilon`, phase counted from the start of the interval.
  Then all cosines equal 1 at the start (the peak of `|u1|`, which the bound of Chapter 6 refers to) and
  every oscillation completes whole periods. Do not restart "when at least epsilon has elapsed".
* **Angles must be continuous (unwrapped).** The privileged coordinates are linear in the angles and do not
  know that an angle is defined modulo 2 pi; wrapping them would make `z` jump.
* **Gain is fixed.** The design gain is tuned along the straight ray to the goal on the nilpotent
  approximation; on the exact kinematics `|u1|` can exceed the limit (thesis Chapter 7, two trailers:
  up to 1.12x after 30 minutes). Set `clip_fraction` below 1 for a margin and watch `cmd.clipped`.
* `cmd.skipped` (`SampledController.skipped`) counts intervals missed because the loop was late.

## Relation to S. Eisner's `controller_main.py`

His node (ROS 2, NatNet, `/cmd_vel`, unwrap of yaw, CSV/plot export) is the model for the node structure;
it is for the car alone (r = 2) and tracks one rigid body. Not taken over: his restart-when-elapsed timing,
the missing saturation. Used under the permission he gave in September 2026; do not publish it.
